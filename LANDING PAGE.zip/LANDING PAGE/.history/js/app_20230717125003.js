/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/

const sectionList=document.querySelectorAll("section");
const myA = document.querySelectorAll('a[href^="#"]');
const navBar = document.querySelector('#navbar__list');

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

function buildNavbar () {
    for (let section of sectionList){
        navbar__menu.innerHTML +=`<il><a class='menu__link' href='#${section.id}'>${section.id}</a></il>`;
    }
}

function addActiveClass() {
    sectionList.forEach(section => {
        if(window.scroll> (section.offsetTop-20)&& window.scroll <(section.offsetTop+offsetHeight)-30  ){
            section.classList.add("your-active-class");
            document.querySelector('a[href^="#${section.id}"]').parentElement.classList.add("active");
        } else{
            section.classList.remove("your-active-class");
            document.querySelector('a[href^="#${section.id}"]').parentElement.classList.remove("active");
        }
    }

    )
    
}


function smoothScroll(){
    navBar.querySelectorAll('a[href^="#').forEach(anchor =>{
        anchor.addEventListener('click', function(e){
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior:'smooth'
            });
        });
    });
}



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav

buildNavbar();

// Add class 'active' to section when near top of viewport

document.addEventListener('scroll',addActiveClass);

// Scroll to anchor ID using scrollTO event

smoothScroll();

/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

<nav class="navbar__menu">
      <ul id="navbar__list">
      <a href="#" class="logo">ActiveLink.</a>
      
          <li class="active">
            <a class="menu__link" href="#section1">SECTION1</a>
          </li> 
          <li class="active">
            <a class="menu__link" href="#section2">SECTION2</a>
          </li> 
          <li class="active">
            <a class="menu__link" href="#section3">SECTION3</a>
          </li> 
          <li class="active">
            <a class="menu__link" href="#section4">SECTION4</a>
          </li> 
        </ul>
      </nav>

// Scroll to section on link click


// Set sections as active*


/* active state to your navigation items */

let sections=document.querySelectorAll('section');
let navLinks=document.querySelectorAll('header nav a');

window.onscroll = () => {
  sections.forEach( sec => {
    let top =window.scrollY;
    let offset= sec.offsetTop -150;
    let height= sec.offsetHeight;
    let id= sec.getAttribute('id');

    if(top >= offset && top < offset + height ) {
      navLinks.forEach(link=> {
          links.classList.remove('active');
          document.querySelector('header nav a[href*=' + id +']').classList.add('active');
        });
    };
  });
};

/*scroll to top button */

let span = document.querySelector(".up");

window.onscroll=function(){
if(this.scrollY>= 1000){
  span.classList.add("show");
} else{
  span.classList.remove("show");

}
};

span.onclick= function(){
window.scrollTo({
  top:0,
  behavior:"smooth",
});
};


/* Hide fixed navigation bar while not scrolling */*css*/`

`
var lastScrollTop = 0;
nav = document.getElementById("nav");
window.addEventListener("scroll",function(){
var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
if (scrollTop>lastScrollTop){
  nav.style.top="-80px";
}else {
  nav.style.top="0px";

}
lastScrollTop=scrollTop;
    
});


/* sections collapsible */

const accordion = document.getElementsByClassName('contentBx');
for(i =0 ; i<accordion.length; i++){
  accordion[i].addEventListener('click', function(){
    this.classList.toggle('active')
  });
};
