/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/

const menu= document.querySelector('nanbar__list');
const sections = document.querySelectorAll('section') ;
console.log(sections)

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/
//build NavBar Menu

const createNavItems = () => {
  navBar.innerHTML = "";
  document.querySelectorAll("section").forEach((section) => {
    const listItem = `<li><a href="#${section.id}" data-nav="${section.id}" class="menu__link">${section.dataset.nav}</a></li>`;
    navBar.insertAdjacentHTML("beforeend", listItem);
  });
};

// Add Active Class

window.onscroll = function() {
	document.querySelectorAll("section").forEach(function(active) {
    let activeLink = navBar.querySelector(`[data-nav=${active.id}]`);
	if(active.getBoundingClientRect().top >= -400 && active.getBoundingClientRect().top <= 150){

    active.classList.add("your-active-class");
    activeLink.classList.add("active-link");

    }
    else{
         active.classList.remove("your-active-class");
         activeLink.classList.remove("active-link");
    }
	});
}
 
  //smooth scroll to section

  navBar.addEventListener("click", (event) => {
    event.preventDefault();
    if (event.target.dataset.nav) {
      document
        .getElementById(`${event.target.dataset.nav}`)
        .scrollIntoView({ behavior: "smooth" });
      setTimeout(() => {
        location.hash = `${event.target.dataset.nav}`;
      }, 200);
    }
  });
  



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav
buildNavbar();

// Add class 'active' to section when near top of viewport
document.addEventListener('scroll',addActiveClass);

// Scroll to anchor ID using scrollTO event
smoothscroll();

/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active

/*scroll to top button */

let span = document.querySelector(".up");

window.onscroll=function(){
if(this.scrollY>= 1000){
  span.classList.add("show");
} else{
  span.classList.remove("show");

}
};

span.onclick= function(){
window.scrollTo({
  top:0,
  behavior:"smooth",
});
};


/* Hide fixed navigation bar while not scrolling */*css*/`

`
var lastScrollTop = 0;
nav = document.getElementById("nav");
window.addEventListener("scroll",function(){
var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
if (scrollTop>lastScrollTop){
  nav.style.top="-80px";
}else {
  nav.style.top="0px";

}
lastScrollTop=scrollTop;
    
});


/* sections collapsible */

const accordion = document.getElementsByClassName('contentBx');
for(i =0 ; i<accordion.length; i++){
  accordion[i].addEventListener('click', function(){
    this.classList.toggle('active')
  });
};




/**
 * create four-section dynamically by javascript instead of HTML
 * create them links
 * ability to observe sections
 */
for (let i = 1; i < 5; i++) createSection();
createNavItems();
// observingSections();

// creating more sections by click on the button
document.getElementById("btn").addEventListener("click", () => {
  createSection();
  createNavItems();
  // observingSections();
});
// save the icon used to go to the top and the header in variables
const toTop = document.getElementById("to-top");
const header = document.querySelector(".page__header");

// Clicking on the icon the document will scroll to the top smoothly
toTop.addEventListener("click", () => {
  document.documentElement.scrollTo({ top: 0, behavior: "smooth" });
});
/**
 * disappear the header after 8 seconds and appear again when scrolling.
 * appearing the icon(to-top) after 800px to down
 */
let isScrolling;
document.onscroll = () => {
  header.style.display = "block"
  clearTimeout(isScrolling)
   isScrolling = setTimeout(() => {
    header.style.display = "none";
  }, 4000);

  window.scrollY > 800
    ? (toTop.style.display = "block")
    : (toTop.style.display = "none");
};